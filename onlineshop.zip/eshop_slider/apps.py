from django.apps import AppConfig


class EshopSliderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eshop_slider'
